package kt20p;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class KiemTra extends JFrame {
    private JTextField txtHoTen, txtNgaySinh, txtQueQuan;
    private JButton btnThem;
    private JTable table;
    private DefaultTableModel tableModel;

    public KiemTra() {
        setTitle("Kiểm Tra");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Thông tin"));

        inputPanel.add(new JLabel("Họ và tên:"));
        txtHoTen = new JTextField();
        inputPanel.add(txtHoTen);

        inputPanel.add(new JLabel("Ngày sinh:"));
        txtNgaySinh = new JTextField();
        inputPanel.add(txtNgaySinh);

        inputPanel.add(new JLabel("Quê quán:"));
        txtQueQuan = new JTextField();
        inputPanel.add(txtQueQuan);

        btnThem = new JButton("Thêm");
        inputPanel.add(btnThem);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{"Họ và tên", "Ngày sinh", "Quê quán"});
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        btnThem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String hoTen = txtHoTen.getText().trim();
                String ngaySinh = txtNgaySinh.getText().trim();
                String queQuan = txtQueQuan.getText().trim();

                if (!hoTen.isEmpty() && !ngaySinh.isEmpty() && !queQuan.isEmpty()) {
                    tableModel.addRow(new Object[]{hoTen, ngaySinh, queQuan});
                    txtHoTen.setText("");
                    txtNgaySinh.setText("");
                    txtQueQuan.setText("");
                } else {
                    JOptionPane.showMessageDialog(KiemTra.this, "Vui lòng nhập đầy đủ thông tin!");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new KiemTra().setVisible(true);
        });
    }
}
