package helloworld;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

public class StudentInfoForm {
    public static void main(String[] args) {
        // Tạo frame
        JFrame frame = new JFrame("Thông tin sinh viên");
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Tạo nhãn và ô nhập cho Họ và tên
        JLabel nameLabel = new JLabel("Họ và tên:");
        nameLabel.setBounds(30, 30, 100, 25);
        JTextField nameField = new JTextField();
        nameField.setBounds(130, 30, 200, 25);

        // Tạo nhãn và ô nhập cho Mã sinh viên
        JLabel idLabel = new JLabel("Mã sinh viên:");
        idLabel.setBounds(30, 70, 100, 25);
        JTextField idField = new JTextField();
        idField.setBounds(130, 70, 200, 25);

        // Tạo nút
        JButton submitButton = new JButton("Hiển thị");
        submitButton.setBounds(130, 110, 100, 30);

        // Tạo nhãn hiển thị kết quả
        JLabel resultLabel = new JLabel("");
        resultLabel.setBackground(Color.WHITE);
        resultLabel.setBounds(30, 150, 300, 25);

        // Thêm sự kiện cho nút
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String id = idField.getText();
                resultLabel.setText("Tên: " + name + ", Mã SV: " + id);
            }
        });

        // Thêm các thành phần vào frame
        frame.getContentPane().add(nameLabel);
        frame.getContentPane().add(nameField);
        frame.getContentPane().add(idLabel);
        frame.getContentPane().add(idField);
        frame.getContentPane().add(submitButton);
        frame.getContentPane().add(resultLabel);

        // Hiển thị frame
        frame.setVisible(true);
    }
}