package btchuong2;

import javax.swing.*;

public class TabbedPaneExample {
    public static void main(String[] args) {
        // Tạo JFrame
        JFrame frame = new JFrame("JTabbedPane Example");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Tạo JTabbedPane
        JTabbedPane tabbedPane = new JTabbedPane();

        // Tạo 3 tab với nội dung khác nhau
        JPanel homePanel = new JPanel();
        homePanel.add(new JLabel("Welcome to the Home tab"));

        JPanel profilePanel = new JPanel();
        profilePanel.add(new JLabel("This is your Profile tab"));

        JPanel settingsPanel = new JPanel();
        settingsPanel.add(new JLabel("Adjust your Settings here"));

        // Thêm các tab vào JTabbedPane
        tabbedPane.addTab("Home", homePanel);
        tabbedPane.addTab("Profile", profilePanel);
        tabbedPane.addTab("Settings", settingsPanel);

        // Thêm JTabbedPane vào frame
        frame.add(tabbedPane);
        frame.setVisible(true);
    }
}
