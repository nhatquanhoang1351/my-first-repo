package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class TemperatureServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String tempStr = request.getParameter("temperature");
        String type = request.getParameter("type");
        double temp = Double.parseDouble(tempStr);
        double result = 0;

        if ("c2f".equals(type)) {
            result = temp * 9 / 5 + 32;
        } else if ("f2c".equals(type)) {
            result = (temp - 32) * 5 / 9;
        }

        request.setAttribute("result", String.format("Kết quả: %.2f", result));
        request.getRequestDispatcher("temp.jsp").forward(request, response);
    }
}
