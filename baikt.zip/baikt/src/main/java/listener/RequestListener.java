package listener;

import jakarta.servlet.*;

public class RequestListener implements ServletRequestListener {
    public void requestInitialized(ServletRequestEvent sre) {
        ServletContext context = sre.getServletContext();
        Integer count = (Integer) context.getAttribute("requestCount");
        if (count == null) count = 0;
        context.setAttribute("requestCount", count + 1);
    }

    public void requestDestroyed(ServletRequestEvent sre) {
        // Do nothing
    }
}
