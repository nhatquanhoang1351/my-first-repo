package bai3;

import javax.servlet.ServletRequestListener;
import javax.servlet.*;

public class RequestListener implements ServletRequestListener {
    public void requestInitialized(ServletRequestEvent sre) {
        ServletContext context = sre.getServletContext();
        Integer count = (Integer) context.getAttribute("requestCount");
        if (count == null) {
            count = 1;
        } else {
            count++;
        }
        context.setAttribute("requestCount", count);
    }

    public void requestDestroyed(ServletRequestEvent sre) {}
}
